/*create a class with constructors and destructors.
create array of instances and observe how program behaves.*/

#include<iostream>
using namespace std;
class Q1
{
	int num;
public:
	Q1()
	{
		num = 0;
		cout<<"In default constructor num = "<<num<<endl;
	};
	Q1(int k)
	{
		k = num;
		cout<<"In parameterized constructor"<<endl;
	};
	~Q1()
	{
		cout<<"Inside the destructor"<<endl;
	};
	void getdata()
	{
		int k;
		cout<<"Enter the value that you wish to store"<<endl;
		cin>>num;
		k = num;
	}
	int putdata()
	{
		return num;
	}
};
void main()
{
	int itr;
	Q1 obj[10];
	cout<<"Enter the number of default constructors you wish to create"<<endl;
	cin>>itr;
	for(int i=0; i<itr;i++)
	{
		obj[i].getdata();
	}
	for(int i=0; i<itr;i++)
	{
		cout<<"The value of num is: "<<obj[i].putdata()<<endl;
	}
}
/*
create a class with constructors and destructor.
create 2 instances on stack and 1 instance on heap. observe the invocation of constructors and destructors.
*/
#include<iostream>
using namespace std;
class Q2
{
	int num;
public:
	Q2()
	{
		num = 0;
		cout<<"Inside the default constructor num = "<<num<<endl;
	}
	Q2 (int num)
	{
		this->num = num;
		cout<<"Inside the parameterised constructor num = "<<num<<endl;
	}
	~Q2()
	{
		cout<<"Inside destructor"<<endl;
	}
	int getnum()
	{
		return num;
	}
	void setnum(int num)
	{
		this->num = num;
		
	}
};
void main()
{
	Q2 obj1;
	obj1.setnum(50);
	cout<<"The new value of num for obj1 is: "<<obj1.getnum()<<endl;
	Q2 obj2(100);
	cout<<"The new value of num for obj2 is: "<<obj2.getnum()<<endl;
	Q2 *obj3 = new Q2(200);
	cout<<"The new value of num for obj3 is: "<<obj3->getnum()<<endl;
	Q2 *obj4 = new Q2[3];
	for(int i=0;i<3;i++)
	{
		int num;
		cout<<"enter value"<<endl;
		cin>>num;
		obj4[i].setnum(num);
	}
	/*for(int j=0;j<3;j++)
	{
		cout<<obj4[j].getnum()<<endl;
	}*/
	for(int i=0;i<3;i++)
	{
		cout<<"The new value of num for obj["<<i<<"] is: "<<obj4[i].getnum()<<endl;
	}
	delete []obj4;
	delete obj3;
}
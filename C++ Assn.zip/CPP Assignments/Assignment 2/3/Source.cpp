/*
3)create a class "MyClass1" with members and member function "disp1().
create another class "MyClass2" with members and member function "disp2().
now try to invoke disp1() from disp2() 
in the main() function, create instances of both the classes and invoke their member functions.
*/
#include<iostream>
using namespace std;
class MyClass2;
class MyClass1
{
	int num1;
public:
	MyClass1()
	{
		cout<<"In default constructor of MyClass1."<<endl;
	}
	MyClass1(int num1)
	{
		this->num1 = num1;
		cout<<"In default constructor of MyClass1."<<endl;
	}
	void disp1(MyClass2 &);
};
class MyClass2
{
	int num2;
public:
	MyClass2()
	{
		cout<<"In default constructor of MyClass2."<<endl;
	}
	MyClass2(int num2)
	{
		this->num2 = num2;
		cout<<"In default constructor of MyClass2."<<endl;
	}
	void disp2()
	{
		//ref.disp1();
		cout<<"The value of num in MyClass2 is: "<<num2<<endl;
	}
};
void MyClass1::disp1(MyClass2 & ref)
{
	ref.disp2();
	cout<<"The value of num in MyClass2 is: "<<num1<<endl;
}
void main()
{
	MyClass1 m1(100);
	MyClass2 m2(200);
	m1.disp1(m2);
}
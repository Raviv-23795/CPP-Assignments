/*
5) create a class, define different types of constructors. in main create n number of objects. 
At the end display how many constructors are created for a class.
*/
#include<iostream>
using namespace std;
class Q5
{
	int num;
	static int cnt;
public:
	Q5()
	{
		cnt++;
		cout<<"Inside default constructor"<<endl;
	}
	Q5(int num)
	{
		cnt++;
		this->num = num;
		cout<<"Inside parameterised constructor"<<endl;
	}
	Q5(Q5 &ref)
	{
		cnt++;
		this->num = ref.num;
		cout<<"Inside copy constructor"<<endl;
	}
	void setnum(int num)
	{
		this->num = num;
	}
	int getnum()
	{
		return num;
	}
	~Q5()
	{
		cnt--;
		cout<<"I'm inside destructor"<<endl;
	}
	static int getcnt()
	{
		return cnt;
	}
};
int Q5::cnt = 0;
void main()
{
	Q5 obj1;
	obj1.setnum(10);
	cout<<obj1.getnum()<<endl;
	Q5 obj2(20);
	cout<<obj2.getnum()<<endl;
	Q5 obj3 = obj2;
	cout<<obj3.getnum()<<endl;
	Q5 obj4(obj1);
	cout<<obj4.getnum()<<endl;
	Q5 *obj5 = new Q5;
	obj5->setnum(30);
	cout<<obj5->getnum()<<endl;
	cout<<"number of constructors created = "<<Q5::getcnt()<<endl;

	delete obj5;
	cout<<"number of constructors = "<<Q5::getcnt()<<endl;
}
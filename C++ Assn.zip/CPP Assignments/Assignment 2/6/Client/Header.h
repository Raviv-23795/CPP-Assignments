/*
6) 
Developer Side
	create a class "book" with
		int bookid
		char *bookname
		int price

	define parameterized constructor only for this class.
	define 3 getter functions.

create necessary header file and distribute it to the client.
*/

class book
{
	int bookid;
	char *bookname;
	int price;
public:
	book(int, char*, int);
	~book();
	int getbookid();
	char* getbookname();
	int getbookprice();
};
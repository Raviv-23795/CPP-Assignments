/*
Developer Side
	create a class "book" with
		int bookid
		char *bookname
		int price

	define parameterized constructor only for this class.
	define 3 getter functions.

create necessary header and lib file and distribute it to the client.

Client Side

	 create 2 instances
	1 on stack and 1 on heap.
	pass the necessary values while creating instances.
	call the getter functions.
*/

#include<iostream>
#include<stdlib.h>
#include"D:\Ravi\Assignment 2\6\Client\Header.h"
using namespace std;
void main()
{
	book b1(1,"let us c",500);
	cout<<"BookID: "<<b1.getbookid()<<endl<<"Book name: "<<b1.getbookname()<<endl<<"Book price: "<<b1.getbookprice()<<endl;

	book *b2 = new book(2,"C++",750);
	cout<<"BookID: "<<b2->getbookid()<<endl<<"Book name: "<<b2->getbookname()<<endl<<"Book price: "<<b2->getbookprice()<<endl;

	delete b2;
}
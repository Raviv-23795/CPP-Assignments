/*
6) 
Developer Side
	create a class "book" with
		int bookid
		char *bookname
		int price

	define parameterized constructor only for this class.
	define 3 getter functions.

create necessary lib file and distribute it to the client.
*/
#include<iostream>
#include "D:\Ravi\Assignment 2\6\Developer\Win32Project1\Win32Project1\Header.h";
using namespace std;
book::book(int bookid, char* bookname, int price)
{
	this->bookid = bookid;
	this->bookname = bookname;
	this->price = price;
	cout<<"Inside parameterized constructor"<<endl;
}

book::~book()
{
	cout<<"Inside the destructor"<<endl;
}

int book:: getbookid()
{
	return bookid;
}

char* book:: getbookname()
{
	return bookname;
}

int book:: getbookprice()
{
	return price;
}
/*
1) 
write a program to convert minutes to hours.
(Use operator= for conversion.)
*/
#include<iostream>
using namespace std;
class Minute;
class Hour
{
	private:
		float hr;
	public:
		Hour(float hr)
		{
			cout<<"In parameterized constructor of hour."<<endl;
			this->hr = hr;
		}
		void disp()
		{
			cout<<"Hours = "<<hr<<endl;
		}
		~Hour()
		{
			cout<<"In hours destructor"<<endl;
		}
		void operator=(Minute& ref);
		float gethrs()
		{
			return hr;
		}
};
class Minute
{
	private:
		float mnt;
	public:
		Minute(float mnt)
		{
			cout<<"In parameterized constructor of minute."<<endl;
			this->mnt = mnt;
		}
		void disp()
		{
			cout<<"Minutes = "<<mnt<<endl;
		}
		~Minute()
		{
			cout<<"In Minutes destructor"<<endl;
		}
		float getmnt()
		{
			return mnt;
		}
};
void Hour ::operator=(Minute& ref)
{
	hr = ref.getmnt()/60;
}

void main()
{
	Hour h1(2);
	h1.disp();
	Minute m1(90);
	m1.disp();
	h1 = m1;
	cout<<h1.gethrs()<<endl;
}
/*
2)write a number class with
int num;
void disp(){}

u should be able to do following

number n1(20);
int k=-n1;

n1+=5;
n1.disp()

number n2(35);
if(n1!=n2)
{
	some message
}



number n3(12);

if(n3 < n1)
{
	some message
}

number n4;

n4=n2*n3;
*/

#include<iostream>
using namespace std;
class Number
{
	int num;
public:
	Number()
	{
		cout<<"In default constructor."<<endl;
	}
	Number(int num)
	{
		this->num = num;
	}
	int disp()
	{
		return num;
	}
	operator int()
	{
		return (num);
	}
	void operator+=(int a)
	{
		num = num+a;
	}
	bool operator!=(Number &ref)
	{
		return (num != ref.num);
	}
	bool operator<(Number &ref)
	{
		return (num < ref.num);
	}
	Number operator*(Number &ref)
	{
		return Number(num*ref.num);
	}
};
void main()
{
	Number n1(20);
	int k = -n1;
	cout<<k<<endl;

	n1+=5;
	cout<<"n1 = "<<n1.disp()<<endl;

	Number n2(35);
	cout<<"n2 = "<<n2.disp()<<endl;
	if(n1!=n2)
	{
		cout<<endl<<"n1!=n2"<<endl;
	}
	else
	{
		cout<<endl<<"n1=n2"<<endl;
	}

	Number n3(25);
	cout<<"n3 = "<<n3.disp()<<endl;
	if(n3 < n1)
	{
		cout<<endl<<"n3<n1"<<endl;
	}
	else
	{
		cout<<endl<<"n3 is greater than or equal to n1"<<endl;
	}

	Number n4;
	n4=n2*n3;
	cout<<"n4 = "<<n4.disp()<<endl;
}
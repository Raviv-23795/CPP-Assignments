/*
1) class First
   {
      char str1[20];
   };
   class Second
   {
      char str2[20];
   };
write a friend function,which will create a  new string containing str1,str2 and also display it.
*/

#include<iostream>
#include<string.h>
using namespace std;
class Second;
class First
{
	char* str1;
public:
	First(char* str1)
	{
		this->str1=new char[strlen(str1)+1];
	    this->str1 = str1;
		cout<<"name copied"<<str1<<endl;
	}
	friend void newstr(First &, Second &);
};
class Second
{
	char* str2;
public:
	Second(char* str2)
	{
		this->str2=new char[strlen(str2)+1];
		this->str2 = str2;
		cout<<"name copied"<<str2<<endl;
	}
	friend void newstr(First &, Second &);
};
void newstr(First &ref1, Second &ref2)
{
	char* res=new char[40];
	strcpy(res,ref1.str1);
	strcat(res,ref2.str2);
	cout<<"The concatenated string is: "<<res<<endl;
}
void main()
{
	First f1("Ravi");
	Second s1(" Verma");
	newstr(f1,s1);
}
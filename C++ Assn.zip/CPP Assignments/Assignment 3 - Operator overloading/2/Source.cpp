/*
2) class sample
   {
	private:
		char ch;
	public:
		sample(char ch)
		{
			this->ch=ch;
		}
  };

given above class.

write a global function "display" which will access "ch" directly and display it.
call this function from main function.
*/
#include<iostream>
using namespace std;
class sample
{
	char ch;
public:
	sample()
	{
		cout<<"Inside default constructor";
	}
	sample(char ch)
	{
		this->ch=ch;
	}
	void setdata(char ch)
	{
		this->ch = ch;
	}
	char getdata()
	{
		return ch;
	}
	friend void display(sample &);
};
void display(sample &ref)
{
	cout<<"The character data is: "<<ref.ch<<endl;
}
void main()
{
	sample s1;
	s1.setdata('c');
	display(s1);
}
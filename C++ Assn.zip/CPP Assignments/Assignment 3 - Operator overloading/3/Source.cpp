/*
3) Given

class Module1
{
	int duration;
	public:
		Module1(int k)
		{
			duration=k;
		}
};

class Module2
{
	int duration;
	public:
		Module2(int k)
		{
			duration=k;
		}
};		
	
write a global function "check" which will take 2 modules (i.e. Module1 and Module2 ) and check whether Modules are same or not.
call this "check" function from main function.	
*/

#include<iostream>
using namespace std;
class Module2;
class Module1
{
	int duration;
	public:
		Module1(int k)
		{
			duration=k;
		}
		friend void check(Module1 &, Module2 &);
};

class Module2
{
	int duration;
	public:
		Module2(int k)
		{
			duration=k;
		}
		friend void check(Module1 &, Module2 &);
};

void check(Module1 &ref1, Module2 &ref2)
{
	if (ref1.duration < ref2.duration)
	{
		cout<<"Module2 is greater than Module1."<<endl;
	}
	else if (ref1.duration > ref2.duration)
	{
		cout<<"Module1 is greater than Module2."<<endl;
	}
	else
	{
		cout<<"Both the Modules 1 and 2 have the same duration."<<endl;
	}
}

void main()
{
	Module1 m1(300);
	Module2 m2(400);
	check(m1,m2);
}
/*
4) Define a class , write two member functions 
	void disp1(){ //some code }
	void disp2(){ // some code }

	Try to call disp1   from    disp2.
*/

#include<iostream>
using namespace std;
class display
{
public:
	void disp1()
	{
		cout<<"Inside Display1"<<endl;
	}
	void disp2()
	{
		disp1();
		cout<<"Inside Display2"<<endl;
	}
};
void main()
{
	display d;
	d.disp2();
}
/*
5) Define a class with constructor and  member function

	create object, call member function
	now create a reference to that object, and using that reference try to call member function
*/

#include<iostream>
using namespace std;
class Reference
{
	int num;
public:
	Reference()
	{
		num = 0;
		cout<<"Inside default constructor."<<endl;
	}
	Reference(int num)
	{
		cout<<"Inside parameterised constructor."<<endl;
		this->num = num;
	}
	~Reference()
	{
		cout<<"Inside the destructor."<<endl;
	}
	void memberfun()
	{
		cout<<"Num = "<<num<<endl;
	}
};

void main()
{
	Reference r1;
	r1.memberfun();
	Reference &ref1 = r1;
	ref1.memberfun();

	Reference r2(100);
	r2.memberfun();
	Reference &ref2 = r2;
	ref2.memberfun();
}